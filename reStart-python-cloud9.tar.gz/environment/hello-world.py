print("Hello, Cloud9!")
