# Create a variable
myValue = 5j

# Print the variable
print(myValue)

# Print the data type of the variable
print(type(myValue))

# Convert number to string and combine with text
print(str(myValue) + " is of the data type " + str(type(myValue)))
